import { Image, MapPin, Compass, Clock } from "lucide-react"

export const ImageIcon = Image
export const MapPinIcon = MapPin
export const CoordinatesIcon = Compass
export const ClockIcon = Clock

